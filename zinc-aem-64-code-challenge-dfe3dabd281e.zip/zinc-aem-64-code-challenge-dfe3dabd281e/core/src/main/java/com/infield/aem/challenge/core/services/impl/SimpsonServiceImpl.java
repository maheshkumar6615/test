package com.infield.aem.challenge.core.services.impl;

import com.infield.aem.challenge.core.models.ApiResponse;
import com.infield.aem.challenge.core.services.SimpsonConfiguration;
import com.infield.aem.challenge.core.services.SimpsonService;
import org.apache.http.HttpResponse;
import org.apache.http.client.fluent.Request;
import org.apache.sling.api.request.RequestParameter;
import org.apache.sling.api.request.RequestParameterMap;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.metatype.annotations.Designate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map.Entry;
import static com.infield.aem.challenge.core.utils.responseUtil.convertStreamToString;;

/**
 * This service is used to make an api call and capture the response and return 
 * to the servlet
 * @author mahesh
 *
 */
@Component(immediate = true, service = SimpsonService.class)
@Designate(ocd = SimpsonConfiguration.class)
public class SimpsonServiceImpl implements SimpsonService {

	private static final Logger logger = LoggerFactory.getLogger(SimpsonServiceImpl.class);

	private String endPoint;

	@Activate
	protected final void activate(SimpsonConfiguration config) {
		endPoint = config.servicename_propertyname();
	}

	/**
	 * This method is used to make an api call and capture the response and return
	 * to the servlet
	 * 
	 * @param map
	 */

	@Override
	public ApiResponse invokeGetService(RequestParameterMap map) {
		ApiResponse apiResponse = null;

		try {
			/*
			 * Below section is used to create the endpoint if the map is not null
			 */
			String tempEndpoint = null;
			if (null != map && map.size() > 0) {
				StringBuffer requestParams = new StringBuffer();
				int i = 1;
				requestParams.append("?");
				for (Entry<String, RequestParameter[]> entry : map.entrySet()) {
					requestParams.append(entry.getKey()).append("=").append(map.getValue(entry.getKey()));
					if (map.size() > i) {
						requestParams.append("&");
					}
					i++;
				}
				tempEndpoint = endPoint + requestParams;
			}else {
				tempEndpoint = endPoint;
			}
			
			HttpResponse response = Request.Get(tempEndpoint)
											.connectTimeout(1000)
											.socketTimeout(1000)
											.execute()
											.returnResponse();
			InputStream inputStream = response.getEntity().getContent();
			String responseString = convertStreamToString(inputStream);
			apiResponse = new ApiResponse(response.getEntity().getContentType().getValue(), responseString, response.getStatusLine().getStatusCode());

		} catch (IOException | IllegalStateException e) {
			logger.error("Exception while calling API");
		}
		return apiResponse;
	}

}
