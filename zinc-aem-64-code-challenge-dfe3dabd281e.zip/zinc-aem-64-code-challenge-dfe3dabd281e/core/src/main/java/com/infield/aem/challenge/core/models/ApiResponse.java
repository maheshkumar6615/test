package com.infield.aem.challenge.core.models;

/**
 * This class has apiResponse object used to store the reposne from the api call
 * @author mahesh
 *
 */
public final class ApiResponse {

    private String contentType;
    private String content;
    private int statusCode;

    public ApiResponse(String contentType, String content, int statusCode) {
        this.contentType = contentType;
        this.content = content;
        this.statusCode = statusCode;
    }

    public String getContentType() {
        return contentType;
    }

    public String getContent() {
        return content;
    }

    public int getStatusCode() {
        return statusCode;
    }
}
