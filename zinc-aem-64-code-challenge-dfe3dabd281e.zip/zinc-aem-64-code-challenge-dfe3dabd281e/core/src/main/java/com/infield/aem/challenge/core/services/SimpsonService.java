package com.infield.aem.challenge.core.services;

import com.infield.aem.challenge.core.models.ApiResponse;

import org.apache.sling.api.request.RequestParameterMap;

/**
 * This is the Interface of the Simpson service
 * @author mahesh
 *
 */
public interface SimpsonService {

    public ApiResponse invokeGetService(RequestParameterMap map);

}
