package com.infield.aem.challenge.core.services;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

/**
 * Below is the configuration class for the simpson service
 * @author mahesh
 *
 */
@ObjectClassDefinition(name = "Simpson configuration service")
public @interface SimpsonConfiguration {

    @AttributeDefinition(
        name = "Simpson GET end point",
        description = "This store the sample endpoint",
        type = AttributeType.STRING
    )
    String servicename_propertyname();
}
