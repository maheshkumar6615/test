package com.infield.aem.challenge.core.servlets;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.infield.aem.challenge.core.models.ApiResponse;
import com.infield.aem.challenge.core.services.SimpsonService;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestParameterMap;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.Servlet;
import java.io.IOException;

/**
 * The below Servlet is used to send a map to OSGI service and perform JSON interactions
 * using Jackson on the response returned from the service
 * 
 * @author mahesh
 *
 */
@Component(immediate = true,
		   service = Servlet.class,
		   property = { Constants.SERVICE_DESCRIPTION + "= Simpson Servlet",
				        "sling.servlet.methods="+ HttpConstants.METHOD_GET,
				        "sling.servlet.paths=/bin/zinc/servlet"
           })

public class SimpsonServlet extends SlingSafeMethodsServlet {

	private static final Logger logger = LoggerFactory.getLogger(SimpsonServlet.class);

	private static final long serialVersionUID = 1L;

	@Reference
	private SimpsonService simpsonService;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {

		RequestParameterMap map = request.getRequestParameterMap();
		
		ApiResponse result = simpsonService.invokeGetService(map);
		
		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode jsonNode = objectMapper.createObjectNode();

		try {
			((ObjectNode) jsonNode).put("StatusCode", result.getStatusCode());
			((ObjectNode) jsonNode).put("ContentType", result.getContentType());
			((ObjectNode) jsonNode).set("response", objectMapper.readTree(result.getContent()));
			response.getWriter().write(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonNode));
		} catch (JsonProcessingException e) {
			logger.error("Exception while reading the response");
			((ObjectNode) jsonNode).put("StatusCode", 500);
			((ObjectNode) jsonNode).put("ContentType", "application/json");
			((ObjectNode) jsonNode).put("response", "Exception while fetching the response from API.");
			response.getWriter().write(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonNode));
		}
	}
}
